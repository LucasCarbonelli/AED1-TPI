int Sistema::cantCultivosCosechables() const{
	int cuenta = 0 ;
	int i = 0 ;

	// Pc: i == 0 $\land$ cuenta == 0 $\land$ prm(dimensiones(campo(this))) > 0 $\land$ sgd(dimensiones(campo(this))) > 0 (por invariante dimensionesValidas de Campo)

	while (i < this->campo().dimensiones().ancho){

		// I: 0 <= i <= prm(dimensiones(campo(this))) $\land$ cuenta == |[1|k <- [0..i), j <- [0..sgd(dimensiones(campo(this)))), estadoDelCultivo((i,j), this) == Cultivo $\land$ estadoDelCultivo((i,j), this) == ListoParaCosechar ]|

		// fv: prm(dimensiones(campo(this))) - i, cota = 0

		cuenta = cuenta + contarFilasCosechables(i);

		i=i+1;
	}

	// Qc: i == prm(dimensiones(campo(this))) $\land$ cuenta == |[1|k <- [0..prm(dimensiones(campo(this)))), j <- [0..sgd(dimensiones(campo(this)))), estadoDelCultivo((i,j), this) == Cultivo $\land$ estadoDelCultivo((i,j), this) == ListoParaCosechar ]|

	return cuenta;
}