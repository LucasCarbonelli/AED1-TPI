int Sistema::cantCultivosCosechables() const{
	int cuenta = 0;
	int i = 0;

	$// Pc: i == 0 \land cuenta == 0 \land prm(dimensiones(campo(this))) > 0$ $(por \ invariante \ dimensionesValidas \ del \ tipo \ Campo)$

	while (i < this->campo().dimensiones().ancho){

		$// I: 0 \leq i \leq prm(dimensiones(campo(this)))$ $\land$ $cuenta == |[1 \mid k \leftarrow [0..i), j \leftarrow [0..sgd(dimensiones(campo(this)))),$ $contenido((k,j), campo(this)) == Cultivo \land estadoDelCultivo((k,j), this) == ListoParaCosechar ]|$

		$// fv: prm(dimensiones(campo(this))) - i,$ $cota = 0$

		cuenta = cuenta + contarFilasCosechables(i);

		i = i + 1;
	}

	$// Qc: i == prm(dimensiones(campo(this)))$ $\land$ $cuenta == |[1 \mid k \leftarrow [0..prm(dimensiones(campo(this)))), \\ j \leftarrow [0..sgd(dimensiones(campo(this)))),$ $contenido((k,j), campo(this)) == Cultivo \land estadoDelCultivo((k,j), this) == ListoParaCosechar ]|$

	return cuenta;
}