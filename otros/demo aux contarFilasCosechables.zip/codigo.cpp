#include "sistema.h"
#include <algorithm>

int Sistema::contarFilasCosechables(int i ) const {
	//E0
	int cuenta = 0 ;
	Posicion p;
	p.x = i;
	int j = 0; 
	//E1
	//Pc: cuenta == 0 && p.x = i && j = 0;
	while (j < this->campo().dimensiones().largo){
		//Ea
		//I: 0 =< j =< campo().dimensiones().largo && cuenta = |[(i,x) | x <- [0 ... j], estadoDelCultivo(i,x) == ListoParaCosechar]|;
		//B: j < this->campo().dimensiones().largo;
		//Fv: campo().dimensiones().largo - j;			c: 0;
		p.y = j;
		//Eb
		if (this->campo().contenido(p) == Cultivo){
			if (this->estadoDelCultivo(p) == ListoParaCosechar){
			cuenta = cuenta + 1;
			}
		}
		j++;
		//Ec
	}
	//Qc: j == campo().dimensiones().largo && cuenta == |[(i,x) | x <- [0 ... j], estadoDelCultivo(i,x) == ListoParaCosechar]|
	return cuenta;
	//E2
}