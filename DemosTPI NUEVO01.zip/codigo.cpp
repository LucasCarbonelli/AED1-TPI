----------------------Vuelo Escalerado-------------------------------
bool Drone::vueloEscalerado() const
{
	return (this->enVuelo() && this->escalerado());
}

bool Drone::escalerado() const {
	Secuencia<Posicion>::size_type i = 0 ;
	bool val = false; 
	if (enVuelo()){
		val = true;
		if (vueloRealizado().size() > 1){
		    
		    $//  P_c: val == True$ $\land$ $i==0$ $\land$ $|vueloRealizado(this)| > 1$
		 
		    
			while ( i < this->vueloRealizado().size() -2 ){
			    $//  I: 0 \leq i \leq |vueloRealizado(this)|-2$ $\land$  $((\forall j \in [0..i)) esEscalerado(this,j)$ $\land$ $val== true)$ $\lor$ $((\exists j \in [0..i))$ $\neg$ $esEscalerado(this,j) \land val==false )$
		     	$//  fv: |vueloRealizado(this)| - 2 - i          c : 0 $
				if (!esEscalerado(i)) {
					val = false;
				}
				i++;
			}
			$//  Qc: i==|vueloRealizado(this)| - 2 \land (((\forall j \in [0..i)) esEscalerado(this,j) \land val== true) \lor ((\exists j \in [0..i))$ $\neg$ $esEscalerado(this,j) \land val==false))$
		}

	}
	return val;
}


bool Drone::esEscalerado(int i) const {
	return (vueloRealizado()[i].x - vueloRealizado()[i+2].x ==1 || vueloRealizado()[i].x - vueloRealizado()[i+2].x == -1 ) && (vueloRealizado()[i].y - vueloRealizado()[i+2].y ==1 || vueloRealizado()[i].y - vueloRealizado()[i+2].y == -1 );
}
 
----------------------Listo Para Cosechar ---------------------------

bool Sistema::listoParaCosechar() const
{
	return cantCultivosCosechables() >= 0.9 * ((campo().dimensiones().ancho * campo().dimensiones().largo) - 2);
}


int Sistema::cantCultivosCosechables() const{
	int cuenta = 0;
	int i = 0;

	$// Pc: i == 0 \land cuenta == 0 \land prm(dimensiones(campo(this))) > 0$ $(por \ invariante \ dimensionesValidas \ del \ tipo \ Campo)$

	while (i < this->campo().dimensiones().ancho){

		$// I: 0 \leq i \leq prm(dimensiones(campo(this)))$ $\land$ $cuenta == |[1 \mid k \leftarrow [0..i), j \leftarrow [0..sgd(dimensiones(campo(this)))),$ $contenido((k,j), campo(this)) == Cultivo \land estadoDelCultivo((k,j), this) == ListoParaCosechar ]|$

		$// fv: prm(dimensiones(campo(this))) - i,$ $cota = 0$

		cuenta = cuenta + contarFilasCosechables(i);

		i = i + 1;
	}

	$// Qc: i == prm(dimensiones(campo(this)))$ $\land$ $cuenta == |[1 \mid k \leftarrow [0..prm(dimensiones(campo(this)))), \\ j \leftarrow [0..sgd(dimensiones(campo(this)))),$ $contenido((k,j), campo(this)) == Cultivo \land estadoDelCultivo((k,j), this) == ListoParaCosechar ]|$

	return cuenta;
}


int Sistema::contarFilasCosechables(int i ) const {
	
	int cuenta = 0 ;
	Posicion p;
	p.x = i;
	int j = 0; 
	
	$//Pc: cuenta == 0 \land p.x = i \land j = 0;$
	while (j < this->campo().dimensiones().largo){
		
		$//I: 0 \leq j \leq sgd(dimensiones(campo(this)))$ $\land$ $cuenta = |[(i,x) | x \leftarrow [0 ... j], estadoDelCultivo((i,x),this) == ListoParaCosechar]|;$
		$//B: j < sgd(dimensiones(campo(this)));$
		$//Fv: sgd(dimensiones(campo(this))) - j;			c: 0;$
		p.y = j;
		
		if (this->campo().contenido(p) == Cultivo){
			if (this->estadoDelCultivo(p) == ListoParaCosechar){
			cuenta = cuenta + 1;
			}
		}
		j++;
		
	}
	$//Qc: j == sgd(dimensiones(campo(this)))$ $\land$ $cuenta == |[(i,x) | x <- [0 ... j], estadoDelCultivo((i,x),this) == ListoParaCosechar]|$
	return cuenta;
	
}




